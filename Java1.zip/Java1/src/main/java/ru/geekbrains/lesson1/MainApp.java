package ru.geekbrains.lesson1;

public class MainApp {
    public static void main(String[] args) {
        //cоздание переменных всех пройденных типов данных, инициализация их значений и печать результата
        byte a=1;
        short b=7;
        int c=5;
        long d=200L;
        float r=80.28f;
        double k=123.223;
        char p='\42';
        boolean u=true;
        System.out.println("byte="+a);
        System.out.println("short="+b);
        System.out.println("int="+c);
        System.out.println("long="+d);
        System.out.println("float="+r);
        System.out.println("double="+k);
        System.out.println("char="+p);
        System.out.println("boolean="+u);

        //вызов метода, вычисляющего выражение a * (b + (c / d)) и печать результата
        float result=calculate(3.1f,4.2f,5.1f,1.2f);
        System.out.println("result="+result );

        // вызов метода, принимающего на вход два целых числа и проверяющего,
        // что их сумма лежит в пределах от 10 до 20 и печать результата
        boolean resultTask=task10and20(14,8);
        System.out.println("resultTask="+resultTask );

        // вызов метода, печатающего в консоль, положительное ли число передали или отрицательное
        positiveCheck(-5);

        // вызов метода, возвращающего true, если число отрицательное, и возвращающего false если положительное
        boolean resultTask2=isNegative(-7);
        System.out.println("resultTask="+resultTask2 );

        // вызов метода, печатающего в консольсообщение «Привет, указанное_имя!»
        greetings("Марина");

        // вызов метода, определяющего, является ли год високосным, и выводящего сообщение в консоль
        isLeapYear(2024);

    }

    // 3. Метод вычисляющий выражение a * (b + (c / d)) и возвращающий результат
    public static float calculate(float a, float b, float c, float d) {
        return a*(b+(c/d));
    }

    // 4. Метод, принимающий на вход два целых числа и проверяющий, что их сумма лежит в пределах от 10 до 20
    public static boolean task10and20(int x1, int x2) {
        if ((x1 + x2 >= 10)&&(x1 + x2 <= 20)) {
            return true;}
        else {return false; }
    }

    // 5. Метод, печатающий в консоль, положительное ли число передали или отрицательное
    public static void positiveCheck(int x1) {
        if (x1 >= 0) {
            System.out.println("Positive");;}
        else {System.out.println("Negative"); }
    }

    // 6. Метод, возвращающий true, если число отрицательное, и возвращающий false если положительное
    public static boolean isNegative(int x1) {
        if (x1< 0) {
            return true;}
        else {return false; }
    }

    // 7. Метод, печатающий в консоль сообщение «Привет, указанное_имя!».
    public static void greetings(String txtToPrint) {
            System.out.println("Привет,"+txtToPrint+"!");;
    }

    // 8. Метод, определяющий, является ли год високосным, и выводящий сообщение в консоль
    public static void isLeapYear(int x1) {
        if ((x1%4 == 0)&&(x1%100 != 0)||(x1%400 == 0)) {
            System.out.println("Leap");;}
        else {System.out.println("nonLeap"); }
    }
}
